﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

namespace Weaver_KatieAssignment4WebApp
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnCustID_Click(object sender, EventArgs e)
        {

            WebRequest r = WebRequest.Create("http://localhost:55600/WebService1.asmx/GetDataByID/");
            r.Method = "POST";
            r.ContentType = "text/xml; charset=utf-8";

            r.Headers.Add("SOAPAction: \"GetDataByID\"");

            r.Credentials = CredentialCache.DefaultCredentials;

            Stream str = r.GetRequestStream();
            StreamWriter strwriter = new StreamWriter(str, Encoding.ASCII);

            StringBuilder soapPayload = new StringBuilder(
                "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\">");
            soapPayload.Append("s:Body>");
            soapPayload.Append("<GetDataByID xmlns=\"http://www.restfulwebservices.net/ServiceContracts/2008/01\">");
            soapPayload.Append("<CustomerID>ALFKI</CustomerID>");
            soapPayload.Append("</GetDataByID>");
            soapPayload.Append("</s:Body>");
            soapPayload.Append("</s:Envelope");

            strwriter.Write(soapPayload.ToString());
            strwriter.Close();

            HttpWebResponse res = (HttpWebResponse)r.GetResponse();
            StreamReader rdr = new StreamReader(res.GetResponseStream());
            string result = rdr.ReadToEnd();
            txtTest.Text = result;


            //Table Output//

            System.Xml.XmlDocument xmlDoc = new System.Xml.XmlDocument();
            xmlDoc.LoadXml(result);

            System.Xml.XmlNodeList node1string; 
            System.Xml.XmlNodeList customerID;
            System.Xml.XmlNodeList companyName;
            System.Xml.XmlNodeList contactName;
            System.Xml.XmlNodeList contactTitle;
            System.Xml.XmlNodeList address;
            System.Xml.XmlNodeList city;
            System.Xml.XmlNodeList region;
            System.Xml.XmlNodeList postalcode;
            System.Xml.XmlNodeList phone;
            System.Xml.XmlNodeList fax;

            node1string = xmlDoc.GetElementsByTagName("Table");
            customerID = xmlDoc.GetElementsByTagName("CustomerID");
            companyName = xmlDoc.GetElementsByTagName("Company Name");

            foreach (System.Xml.XmlNode n in node1string)
            {
                System.Xml.XmlElement xe;
                xe = (System.Xml.XmlElement)n;
            }
            foreach (System.Xml.XmlNode n in companyName)
                {

                System.Xml.XmlElement xe;
                xe = (System.Xml.XmlElement)n;
                txtCustID.Text = xe.InnerText;

                TableRow chosencompanyName = new TableRow();
                TableCell compName = new TableCell();
                compName.Controls.Add(new LiteralControl("Company Name: "));
                TableCell selectedcompany = new TableCell();
                selectedcompany.Controls.Add(new LiteralControl(xe.InnerText));

                chosencompanyName.Cells.Add(compName);
                chosencompanyName.Cells.Add(selectedcompany);

                tblResults.Rows.Add(chosencompanyName);
            }

        }
    }
}