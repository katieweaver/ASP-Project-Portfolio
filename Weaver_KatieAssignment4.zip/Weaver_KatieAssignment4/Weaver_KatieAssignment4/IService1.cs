﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace Weaver_KatieAssignment4
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface ICustomerService
    {

        [OperationContract]
        string GetCustomerData (int CustomerID);

        //[OperationContract]
        //CustomerInformation GetCustomerInfo(int CustomerID);


        // TODO: Add your service operations here
    }
    public interface ICustomerService2
    {
        [OperationContract]
        string GetCustomerTable(int CustomerTbl);
    }




    // Use a data contract as illustrated in the sample below to add composite types to service operations.
    [DataContract]
    public class CustomerInformation
    {
        internal int IntValue;
        internal string StringValue;
        internal object CustomerTypeList;
        int _CustomerID;
        string _CompanyName;
        string _ContactName;

        public CustomerInformation(int custID, string compName, string contactName)
        {
           int _CustomerID = custID;
           string _CompanyName = compName;
           string _ContactName = contactName;
        }

        [DataMember]
        public int CustomerID
        {
            get { return _CustomerID; }
            set { _CustomerID = value; }
        }

        [DataMember]
        public string CompanyName
        {
            get { return _CompanyName; }
            set { _CompanyName = value; }
        }

        [DataMember]
        public string ContactName
        {
            get { return _ContactName; }
            set { _ContactName = value; }
        }

    }

    [DataContract]
    public class CompositeType
    {
        internal string StringValue;
        internal int IntValue;
        internal object CompositeTypeList;
    }
}
