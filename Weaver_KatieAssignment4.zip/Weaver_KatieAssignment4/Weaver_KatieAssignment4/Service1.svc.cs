﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace Weaver_KatieAssignment4
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : ICustomerService
    {
        public string GetCustomerData(int value)
        {
            var connectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;

            SqlConnection sqlc = new SqlConnection();
            sqlc.ConnectionString = connectionString;
            sqlc.Open();

            SqlCommand sqlCommand = new SqlCommand("SELECT * FROM Customers");
            sqlCommand.CommandType = CommandType.Text;

            sqlc.ConnectionString = connectionString;

            sqlCommand.Connection = sqlc;
            SqlDataAdapter sqlda = new SqlDataAdapter(sqlCommand);
            DataSet dsCurrent = new DataSet();
            sqlda.Fill(dsCurrent);

            DataTable dt = dsCurrent.Tables[0];

            CompositeType ct = new CompositeType();
            return ct.ToString();
        }

        public CompositeType GetCustomerInfo(CompositeType composite)
        {
            if (composite == null)
            {
                throw new ArgumentNullException("composite");
            }
            return composite;
        }




        }


    }
