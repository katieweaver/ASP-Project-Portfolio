﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;

namespace Weaver_KatieAssignment4
{
    /// <summary>
    /// Summary description for WebService1
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class WebService1 : System.Web.Services.WebService
    {

        [WebMethod]
        public DataTable GetDataByID(string CustID)
        {
            {
                var connectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;

                SqlConnection sqlc = new SqlConnection();
                sqlc.ConnectionString = connectionString;
                sqlc.Open();

                if (CustID == "" || CustID == null)
                {
                    SqlCommand sqlCommand = new SqlCommand("SELECT * FROM Customers");
                    sqlCommand.CommandType = CommandType.Text;

                    sqlCommand.Connection = sqlc;
                    SqlDataAdapter sqlda = new SqlDataAdapter(sqlCommand);
                    DataSet dsCurrent = new DataSet();
                    sqlda.Fill(dsCurrent);

                    DataTable dt = dsCurrent.Tables[0];

                    CompositeType ct = new CompositeType();
                    return dt;
                }
                else
                {
                    SqlCommand sqlCommand = new SqlCommand("SELECT * FROM Customers WHERE CustomerID = '"+CustID+"'");
                    sqlCommand.CommandType = CommandType.Text;

                    sqlCommand.Connection = sqlc;
                    SqlDataAdapter sqlda = new SqlDataAdapter(sqlCommand);
                    DataSet dsCurrent = new DataSet();
                    sqlda.Fill(dsCurrent);

                    DataTable dt = dsCurrent.Tables[0];

                    CompositeType ct = new CompositeType();

                    return dt;

                }



            }
        }
    }
}
